﻿define("epi-ecf-ui/contentediting/editors/VariantCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/VariantCollectionReadOnlyEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor"
],
function (
    //dojo
    declare,
    
    // epi commerce
    ReadOnlyCollectionEditor,
    VariantCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/VariantCollectionReadOnlyEditor
        // summary:
        //      Represents the Read-only editor widget for variations.

        iconClass: "epi-iconObjectVariation",

        modelType: VariantCollectionReadOnlyEditorModel,

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", res.nodatamessage);
            this.inherited(arguments);
        },
               
        changeToView: "variantview",

        buttonLabel: res.editbuttontext
    });
});