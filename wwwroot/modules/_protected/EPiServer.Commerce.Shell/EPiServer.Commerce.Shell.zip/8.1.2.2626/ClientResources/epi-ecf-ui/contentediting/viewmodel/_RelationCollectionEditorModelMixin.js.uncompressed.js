﻿define("epi-ecf-ui/contentediting/viewmodel/_RelationCollectionEditorModelMixin", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/topic",
    "dojo/when",
    "dojo/_base/json",

     // dojox
     "dojox/html/entities",

    // epi
    "epi/shell/command/DelegateCommand",
    "epi/shell/widget/dialog/Alert",
    "epi/string",

    // epi cms
    "epi-cms/dgrid/formatters",

    // Resources
    "epi/i18n!epi/nls/episerver.shared"
],
function (
    //dojo
    array,
    declare,
    lang,
    promiseAll,
    topic,
    when,
    json,

     // dojox
    htmlEntities,

    // epi
    DelegateCommand,
    Alert,
    epistring,

    // epi cms
    formatters,

    // Resources
    sharedResources
) {
    
    return declare([], {

        // module:
        //      epi-ecf-ui/contentediting/viewmodel/_RelationCollectionEditorModelMixin
        // summary:
        //      Mixes in overrides of CollectionEditorModel, which can be used by a relation collection editor model to get save, move, remove functionality etz.

        res: null,

        postscript: function(){
            this.inherited(arguments);

            this.own(topic.subscribe("relationChanged", lang.hitch(this, this._refresh)));
        },

        generateColumnsDefinition: function () {
            // summary:
            //      Generate columns definition.
            // tags:
            //      public

            return {
                contentTypeIdentifier: {
                    label: "",
                    className: "epi-columnIcon16x16",
                    formatter: lang.hitch(this, formatters.contentIcon)
                },
                name: {
                    label: this.res.headings.name
                },
                path: {
                    label: this.res.headings.path
                }
            };
        },
        
        getItemCommands: function() {
            var commands = this.inherited(arguments);
            
            if (commands) {
                for (var i = 0; i < commands.length; i++) {
                    if (commands[i].name === "remove") {
                        commands[i].iconClass = "epi-iconClose";
                    }
                }
            }
            
            return commands;
        },

        getListCommands: function (availableCommands) {

            return [
                new DelegateCommand({
                    name: "add",
                    label: this.res.addlabel,
                    tooltip: sharedResources.action.add,
                    iconClass: "epi-iconPlus",
                    canExecute: true,
                    isAvailable: true,
                    delegate: lang.hitch(this, this.addItemDelegate)
                })
            ];
        },
             

        addItem: function (item, refItem, before) {
            var items = this.get("items");
            if (items && items.length > 0) {
                // check if adding item is existed, to move it to above
                // instead of adding duplicated item.
                var itemIdentifier = item.permanentUrl || item.target;
                var existingItem;
                array.some(items, function (oldItem) {
                    if (oldItem && oldItem.target === itemIdentifier) {
                        existingItem = oldItem;
                        return true;
                    }
                });

                if (existingItem) {
                    this.moveItem(existingItem, refItem || existingItem, before || true);
                    return this._refresh();
                }
            }

            // Set sort order before inherited to avoid including new items sort order in calculation
            this._setSortOrder(item, refItem, before);
            return when(this.inherited(arguments), lang.hitch(this, function () {
                return when(this._store.add(item), lang.hitch(this, function () {                    
                    return this._refresh();
                }),
                lang.hitch(this, function (error) {
                    return this._showNotification(error);
                }));
            }));
        },

              moveItem: function (item, refItem, before) {
            return when(this.inherited(arguments), lang.hitch(this, function () {
                this._setSortOrder(item, refItem, before);
                return when(this._store.put(item), lang.hitch(this, function () {
                    return this._refresh();
                }),
                lang.hitch(this, function (error) {
                    return this._showNotification(error);
                }));
            }));
        },

        removeItem: function (item) {
            return when(this.inherited(arguments), lang.hitch(this, function () {
                return when(this._store.remove(item.id), lang.hitch(this, function () {
                    return this._refresh();
                }),
                lang.hitch(this, function (error) {
                    return this._showNotification(error);
                }));
            }));           
        },

        saveItem: function (item, index) {
            return when(this.inherited(arguments), lang.hitch(this, function () {
                return when(this._store.put(item), lang.hitch(this, function () {
                    return this._refresh();
                }),
                lang.hitch(this, function (error) {
                    return this._showNotification(error);
                }));
            }));
        },

        _showNotification: function (error) {
            // summary:
            //      Uses the alert dialog implementation to notify with the error message

            if (error.status === 400) {
                var dialog = new Alert({
                    destroyOnHide: true,
                    description: epistring.toHTML(htmlEntities.encode(json.fromJson(error.xhr.responseText))),
                    onAction: lang.hitch(this, function () {
                        this._refresh();
                    })
                });
                dialog.show();
            }
        },

        _refresh: function () {
            // This will force a refresh of the grid.
            this.set("data", this.get("data"));
        },
        
        _setSortOrder: function(item, refItem, before) {
            if (refItem) {
                // Set sortOrder equal to refItem to place it before
                // The store will update sort index of any items after it
                item.sortOrder = before ? refItem.sortOrder : refItem.sortOrder + 1;
            } else {
                // Place last
                var items = this.get("items");
                var lastSortOrder = (items.length > 0) ? items[items.length - 1].sortOrder : 0;
                if (!item.sortOrder || lastSortOrder >= item.sortOrder) {
                    item.sortOrder = lastSortOrder + 100;
                }
            }
        }
    });
});