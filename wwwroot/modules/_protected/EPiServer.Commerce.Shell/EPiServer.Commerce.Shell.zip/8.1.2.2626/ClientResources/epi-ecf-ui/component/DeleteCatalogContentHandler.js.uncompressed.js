﻿define("epi-ecf-ui/component/DeleteCatalogContentHandler", [
    //Dojo
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/Deferred",
        "dojo/topic",
    //EPi
        "./DeleteConfirmation"
], function (
    //Dojo
        declare,
        lang,
        Deferred,
        topic,
        //Commerce
        DeleteConfirmation
) {
     //summary:
     //     Adds confirmation before executing delete command and hide dialog after delete is done.

    var handler = function (settings) {

        var deferred = new Deferred(),
            dialog = new DeleteConfirmation(settings);

        dialog.connect(dialog, "onAction", function (confirm) {
            if (confirm) {
                deferred.resolve();
            } else {
                deferred.cancel();
            }
        });

        dialog.show();

        topic.subscribe("catalogContentDeleted", function () {
            dialog.hide();
        });
        topic.subscribe("/epi/cms/action/delete/error", function(){
            dialog.hide();
        });

        return deferred;
    };

    return handler;
});